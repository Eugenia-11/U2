package sec03.object;

public class Cup {
	private Object beverage;

	public Object getBeverage() {
		return beverage;
	}

	public void setBeverage(Object beverage) {
		this.beverage = beverage;
	}
}