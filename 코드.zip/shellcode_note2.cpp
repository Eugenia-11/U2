#include "stdafx.h"
#include "windows.h"

int main(int argc, char* argv[])
{
	__asm {
		//char buf[8] = { 'n','o','t','e','p','a','d','\x0' };
		mov         byte ptr[ebp - 8], 6Eh
		mov         byte ptr[ebp - 7], 6Fh
		mov         byte ptr[ebp - 6], 74h
		mov         byte ptr[ebp - 5], 65h
		mov         byte ptr[ebp - 4], 70h
		mov         byte ptr[ebp - 3], 61h
		mov         byte ptr[ebp - 2], 64h
		xor         ebx, ebx
		mov         [ebp - 1], ebx
		//WinExec(buf, SW_SHOW);75DCF57E
		push        5
		lea         eax, [ebp - 8]
		push        eax
		mov         eax, 0x75DCF57E
		call        eax
		//ExitProcess(1);75D9BED2 
		push        1
		mov         eax, 0x75D9BED2
		call        eax
	};
}