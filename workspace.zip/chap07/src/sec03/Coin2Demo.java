package sec03;

public class Coin2Demo implements Coin {
	public static void main(String[] args) {

		System.out.println("Dime�� " + DIME + "��Ʈ�Դϴ�.");

	}
}
