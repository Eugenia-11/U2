package sec03;

public class While1Demo {
	public static void main(String[] args) {
		int i = 1;
		while (i < 5) {
			System.out.print(i);
			i++;
		}
	}
}
