#include "stdafx.h"
#include "windows.h"

int main(int argc, char* argv[])
{
	char buf[8] = { 'w','o','r','d','p','a','d','\x0' };
	WinExec(buf, SW_SHOW);
	ExitProcess(1);
}