package sec06.other;

import sec06.One;

public class Three {
	void print() {
		One o = new One();
		// System.out.println(o.secret);
		// System.out.println(o.roomate);
		// System.out.println(o.child);
		System.out.println(o.anybody);
	}
}
