package sec03;

public class TypeMismatch {
	public static void main(String[] args) {
		byte b;
		// b = 500;
	}
}
