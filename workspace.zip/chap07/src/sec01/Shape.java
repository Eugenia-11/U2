package sec01;

abstract class Shape {
	double pi = 3.14;

	abstract void draw();

	public double findArea() {
		return 0.0;
	}
}