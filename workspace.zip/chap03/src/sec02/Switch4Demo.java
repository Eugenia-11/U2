package sec02;

public class Switch4Demo {
	public static void main(String[] args) {
		int number = 3;

		switch (number) {
		case 4:
			System.out.print("*");
		case 3:
			System.out.print("*");
		case 2:
			System.out.print("*");
		case 1:
			System.out.print("*");
		}
	}
}
