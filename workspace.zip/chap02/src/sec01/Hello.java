package sec01;

public class Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("�ȳ�!"+"!");
		String hello = "�ȳ�!";
		System.out.println(hello);
		
	}

}
