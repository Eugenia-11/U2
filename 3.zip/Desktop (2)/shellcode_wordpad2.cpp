#include "stdafx.h"
#include "windows.h"

int main(int argc, char* argv[])
{
	__asm {
		//char buf[8] = { 'w','o','r','d','p','a','d','\x0' };
		mov         byte ptr[ebp - 8], 77h
		mov         byte ptr[ebp - 7], 6Fh
		mov         byte ptr[ebp - 6], 72h
		mov         byte ptr[ebp - 5], 64h
		mov         byte ptr[ebp - 4], 70h
		mov         byte ptr[ebp - 3], 61h
		mov         byte ptr[ebp - 2], 64h
		xor         ebx, ebx
		mov         [ebp - 1], ebx
		//WinExec(buf, SW_SHOW);7585F57E
		push        5
		lea         eax, [ebp - 8]
		push        eax
		mov  eax, 0x7585F57E
		call        eax
		//ExitProcess(1); 7582BED2
		push        1
		mov  eax, 0x7582BED2
		call        eax
	};
}