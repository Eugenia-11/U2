package sec04;

public class LocalVariableDemo {
	public static void main(String[] args) {
		int a = 0;
		double b;

		// System.out.print(b);
		// System.out.print(a + c);

		int c = 0;

		// public double d = 0.0;

		for (int e = 0; e < 10; e++) {
			// int a = 1;
			System.out.print(e);
		}
	}
}