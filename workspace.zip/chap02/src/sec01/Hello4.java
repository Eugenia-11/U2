package sec01;

public class Hello4 {
	public static void main(String[] args) {
		String hello = "�ȳ�!";
		System.out.println(hello);
	}
}
